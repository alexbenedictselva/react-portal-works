import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';
const Navbar = () => {
  return (
    <>
    <nav>
      <ul>
        <div className="logo">Blood Donation</div>
        <li><Link to="/">login</Link></li>
        <li><Link to="/Home">Home</Link></li>
        <li><Link to="/register"> Donor</Link></li>
        <li><Link to="/request">Request Blood</Link></li>
      </ul>
    </nav>
    </>
  );
};
export default Navbar;

