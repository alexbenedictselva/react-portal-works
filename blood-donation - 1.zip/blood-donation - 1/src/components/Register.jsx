import React from 'react';
import { Link } from 'react-router-dom';

const Register = () => (
    <div className="container">
        <form>
        <h2>Register</h2>
            <label>First Name</label>
            <input
                type="text"
                placeholder="Enter your first name"
                required
            />

            <label>Last Name</label>
            <input
                type="text"
                placeholder="Enter your last name"
                required
            />

            <label>Date of Birth</label>
            <input
                type="date"
                required
            />

            <label>Gender</label>
            <select required>
                <option value="" disabled>Select gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label>Mobile No</label>
            <input
                type="tel"
                placeholder="Enter your mobile number"
                required
            />

        

            <Link to="/">
                <button type="submit">Register</button>
            </Link>

            <p>Already have an account? <Link to="/">Login here</Link></p>
        </form>
    </div>
);

export default Register;
