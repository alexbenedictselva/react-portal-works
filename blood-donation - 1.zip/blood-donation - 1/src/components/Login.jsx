import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";


export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ email: '', password: '' });
  const navigate = useNavigate(); 

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;

  const handleSubmit = (e) => {
    e.preventDefault();

    let errorMessages = { email: '', password: '' };
    let valid = true;

    if (!emailRegex.test(email)) {
      valid = false;
      errorMessages.email = 'Please enter a valid email address.';
    }

    if (!passwordRegex.test(password)) {
      valid = false;
      errorMessages.password = 'Password must be at least 8 characters long, include one letter and one number.';
    }

    
    if (valid) {
      console.log('Login successful');
      navigate("/Home");
    }
    
    setErrors(errorMessages);
  };

  return (
    <div>
      <div className="container">
        <form onSubmit={handleSubmit}>
          <h2>Login</h2>

          <div>
            <label>Email:</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
            />
            {errors.email && <p className="error">{errors.email}</p>}
          </div>

          <div>
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
            />
            {errors.password && <p className="error">{errors.password}</p>}
          </div>

          <button type="submit">Login</button>

          <p>
            Don't have an account? <Link to="/new">Register here</Link>
          </p>
        </form>
      </div>
    </div>
  );
};
